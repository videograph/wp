<?php

add_shortcode('videograph', 'videograph_shortcode');
function videograph_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'content_id' => '',
        ),
        $atts
    );
    
    if (empty($atts['content_id'])) {
        return '';
    }
    
    $url = "https://dashboard.videograph.ai/videos/embed?videoId=" . esc_attr($atts['content_id']);
    
    ob_start();
    ?>
    <div class="video-iframe">
        <iframe loading="lazy" src="<?php echo esc_url($url); ?>" width="100%" height="100%" frameborder="0" scrolling="no" allowfullscreen="true" style="max-width: 100%; max-height: 550px;"></iframe>
    </div>
    <?php
    
    return ob_get_clean();
}

// Library page
function videograph_ai_library_page()
{   
    // Check if API keys are inserted
    $access_token = get_option('videograph_ai_access_token');
    $secret_key = get_option('videograph_ai_secret_key');

    if (empty($access_token) || empty($secret_key)) {
        echo '<div class="vi-notice-error"><p>API key is not added / valid. Please a to <a href="' . admin_url('admin.php?page=videograph-ai-settings') . '">settings</a> page and update it with correct one. </p></div>';
        return;
    }

    $api_url = 'https://api.videograph.ai/video/services/api/v1/contents';
    $headers = array(
        'Authorization' => 'Basic ' . base64_encode($access_token . ':' . $secret_key),
        'Content-Type' => 'application/json',
    );

    $response = wp_remote_get($api_url, array('headers' => $headers));

    if (is_wp_error($response)) {
        echo '<div class="notice notice-error"><p>Failed to fetch videos from Videograph AI API.</p></div>';
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $response_code = wp_remote_retrieve_response_code($response);

    // Check if the API request was successful
    if ($response_code !== 200) {
        echo '<div class="notice notice-error"><p>Failed to fetch videos from Videograph AI API. Check your API Credentials in <a href="' . admin_url('admin.php?page=videograph-ai-settings') . '">Settings</a> Page</p></div>';
        return;
    }

    $videos = json_decode($body, true);

    // Check if the response is valid and contains an array of videos
    if (!is_array($videos) || empty($videos['data'])) {
        echo '<div class="notice notice-error"><p>No Videos Found. You can add videos from <a href="' . admin_url('admin.php?page=videograph-ai-add-new-video') . '">here</a></p></div>';
        return;
    }

    $view_mode = isset($_GET['view']) ? $_GET['view'] : 'list';
    $valid_view_modes = array('grid', 'list');

    if (!in_array($view_mode, $valid_view_modes)) {
        $view_mode = 'list';
    }

    $search_query = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    // Custom filtering function based on the search query
    function custom_video_filter($content, $search_query) {
        return strpos($content['contentId'], $search_query) !== false
            || strpos($content['title'], $search_query) !== false;
    }

    // Filter videos based on the search query
    if (!empty($search_query)) {
        $filtered_videos = array_filter($videos['data'], function ($content) use ($search_query) {
            return custom_video_filter($content, $search_query);
        });
    } else {
        $filtered_videos = $videos['data'];
    }

    // If search query provided and no matching videos found
    if (!empty($search_query) && empty($filtered_videos)) {
        echo '<div class="notice notice-warning"><p>No Videos found matching the search query: ' . esc_html($search_query) . '</p></div>';
    }

    //$per_page = 12; // Number of videos per page
    $per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 10;
    $total_videos = count($filtered_videos);
    $total_pages = ceil($total_videos / $per_page);
    $current_page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;

    $start_index = ($current_page - 1) * $per_page;
    $end_index = $start_index + $per_page;
    $videos_data = array_slice($filtered_videos, $start_index, $per_page);
    
    // Display videos
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">Videograph AI Library</h1>
        <a href="<?php echo admin_url('admin.php?page=videograph-ai-add-new-video') ?>" class="page-title-action">Add New</a>
        <hr class="wp-header-end">
        <div class="wp-filter">
            <div class="filter-items">
                <div class="view-switch <?php echo $view_mode; ?>">
                    <a href="<?php echo esc_url(add_query_arg('view', 'list')); ?>" class="view-list" id="view-switch-list" >
                        <span class="screen-reader-text">List view</span>
                    </a>
                    <a href="<?php echo esc_url(add_query_arg('view', 'grid')); ?>" class="view-grid" id="view-switch-grid" aria-current="page">
                        <span class="screen-reader-text">Grid view</span>
                    </a>
                </div>
            </div>
            <div>
                <form id="videos-per-page-form" method="GET" action="<?php echo esc_url(admin_url('admin.php')); ?>">
                    <input type="hidden" name="page" value="videograph-ai-library">
                    <div class="videos-count">
                        <label for="videos-per-page">Videos per page</label>
                        <select id="videos-per-page" name="per_page">
                            <option value="10" <?php selected($per_page, 10); ?>>10</option>
                            <option value="20" <?php selected($per_page, 20); ?>>20</option>
                            <option value="30" <?php selected($per_page, 30); ?>>30</option>
                            <!-- Add other options as needed -->
                        </select>
                        <input type="submit" name="submit" value="Submit" class="button button-primary">
                    </div>
                </form>

                <div class="search-form">
                    <label for="media-search-input" class="media-search-input-label">Search</label>
                    <input type="search" id="media-search-input" class="search" name="s" value="<?php echo esc_attr($search_query); ?>" />
                </div>
            </div>
            
        </div>
        
        <div class="video-container <?php echo ($view_mode === 'list') ? 'list-view' : 'grid-view'; ?>">
            <table class="wp-list-table widefat fixed striped table-view-list posts">
    <thead>
        <tr>
            <th scope="col" class="manage-column">Created at</th>
            <th scope="col" class="manage-column">Title</th>
            <th scope="col" class="manage-column">Video ID</th>
            <th scope="col" class="manage-column">Thumbnail</th>
            <th scope="col" class="manage-column">Duration</th>
            <th scope="col" class="manage-column">Resolution</th>
            <th scope="col" id="date" class="manage-column">Status</th>
            <th scope="col" id="date" class="manage-column">Actions</th>
        </tr>
    </thead>
    <tbody id="the-list">
        <?php foreach ($videos_data as $content) { 
            $created_at = $content['created_at'];
            $timestamp = $created_at / 1000;
            $date = date('Y-m-d H:i:s', strtotime('@' . $timestamp));
            $duration = $content['status'] === 'Ready' ? gmdate('H:i:s', round($content['duration'] / 1000)) : '_';
            $resolution = $content['status'] === 'Ready' ? $content['resolution'] : '_';
        ?>
        <tr>
            <td><?php echo esc_html($date); ?></td>
            <td>
                <a href="#video-popup-<?php echo esc_attr($content['contentId']); ?>" class="video-thumbnail">
                    <?php echo esc_html($content['title']); ?>                      
                </a>
            </td>
            <td>
                <a href="#video-popup-<?php echo esc_attr($content['contentId']); ?>" class="video-thumbnail">
                    <?php echo esc_attr($content['contentId']); ?>
                </a>
            </td>
            <td>
                <a href="#video-popup-<?php echo esc_attr($content['contentId']); ?>" class="video-thumbnail">
                    <figure style="background-image: url(<?php echo esc_url($content['thumbnailUrl']); ?>);"></figure>
                </a>
            </td>
            <td><?php echo esc_attr($duration); ?></td>
            <td><?php echo esc_attr($resolution); ?></td>
            <td id="<?php echo esc_attr($content['status']); ?>" class="status">
                <p class="process">Processing <span class="dashicons dashicons-update"></span></p>
                <p class="ready">Ready <span class="dashicons dashicons-yes-alt"></span></p>
                <p class="failed">Failed <span class="dashicons dashicons-dismiss"></span></p>
            </td>
            <td>
                <div class="video-actions">
                    <button class="video-actions-btn">
                        <span class="dots">.</span>
                    </button>
                    <div class="video-actions-menu">
                        <ul>
                            <li><a href="#video-popup-<?php echo esc_attr($content['contentId']); ?>" class="video-thumbnail">
                                <span class="dashicons dashicons-info"></span>Video Details
                            </a></li>
                            <li><a href="#" class="video-delete" data-content-id="<?php echo esc_attr($content['contentId']); ?>">
                                <span class="dashicons dashicons-trash"></span>Delete Video
                            </a></li>
                        </ul>
                    </div>
                </div>
            </td>
        </tr>
                <div class="video-item">
                        <a href="#video-popup-<?php echo esc_attr($content['contentId']); ?>" class="video-thumbnail "></a>
                        <figure style="background-image: url(<?php echo esc_url($content['thumbnailUrl']); ?>);"></figure>
                        <h3 class="video-title"><?php echo esc_html($content['title']); ?></h3>                        
                                        
                </div>
                    <div id="video-popup-<?php echo esc_attr($content['contentId']); ?>" class="video-popup">
                        <div class="close-button"></div>
                        <div class="video-popup-cnt">
                            <div class="video-popup-header">
                                <h2>Video Details</h2>
                                <button class="close-button"><span class="dashicons dashicons-no"></span></button>
                            </div>
                            <div class="video-popup-main">
                                <div class="video-popup-main-left">
                                    <div class="video-player">
                                        <?php $url = "https://dashboard.videograph.ai/videos/embed?videoId=" . esc_attr($content['contentId']); ?>
                                        <iframe src="<?php echo esc_url($url); ?>" frameborder="0" allowfullscreen></iframe>
                                    </div>
                                </div>
                                <div class="video-popup-main-right">
                                    <div class="video-details-top">
                                        <p><strong>File Name: </strong> <?php echo esc_html($content['title']); ?></p>
                                            <?php
                                                $created_at = $content['created_at'];
                                                $timestamp = $created_at / 1000;
                                                $date = date('Y-m-d H:i:s', strtotime('@' . $timestamp));
                                                
                                            ?>
                                        <p><strong>Created On: </strong> <?php echo esc_html($date); ?></p>
                                        <p><strong>Published On: </strong> <?php echo esc_html($date); ?></p>
                                        <p><strong>Video updated On: </strong> <?php echo esc_html($date); ?></p>
                                    </div>

                                    <div class="video-details-main">
                                        <!-- <div class="vi-policy">
                                            <p>
                                                <strong>Private</strong>
                                                <input type="checkbox" name="">
                                            </p>
                                            <p>
                                                <strong>Enable Download</strong>
                                                <input type="checkbox" name="">
                                            </p>
                                        </div> -->
                                        <p>
                                            <strong>Title: </strong> 
                                            <input type="text" value="<?php echo esc_attr($content['title']); ?>">
                                        </p>
                                        <p>
                                            <strong>Description: </strong>
                                            <textarea>
                                                <?php echo !empty($content['description']) ? esc_html($content['description']) : ''; ?>
                                            </textarea>
                                        </p>
                                        <p>
                                            <strong>Tags: </strong>
                                            <input type="text" value="">
                                        </p>
                                        <p>
                                            <strong>Video Shortcode: </strong>
                                            <input type="text" value="[videograph content_id='<?php echo esc_attr($content['contentId']); ?>']" readonly>
                                        </p>
                                        <?php $url = "https://dashboard.videograph.ai/videos/embed?videoId=" . esc_attr($content['contentId']); ?>
                                        <p><strong>Sharable URL</strong> <input type="text" value="<?php echo esc_html($url); ?>" readonly></p>
                                    </div>

                                    <div class="video-details-bottom">                                        
                                        <?php $url = "https://dashboard.videograph.ai/videos/embed?videoId=" . esc_attr($content['contentId']); ?>
                                        <a href="<?php echo esc_html($url); ?>" class="video-download" download target="_blank">Download</a><span>|</span>
                                        <a href="https://dashboard.videograph.ai/" target="_blank">Edit on videograph.ai</a> <span>|</span>
                                        <a href="#" class="video-delete" data-content-id="<?php echo esc_attr($content['contentId']); ?>">Delete Permanently</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            <?php } ?>
                </tbody>
            </table>
        </div>


<?php
    // Pagination HTML
    if ($total_pages > 1) {
        echo '<div class="pagination">';

        echo '<span class="displaying-num">' . $total_videos  . ' items </span>';

        if ($current_page > 1) {
            $prev_page = $current_page - 1;
            $prev_url = add_query_arg(array('paged' => $prev_page, 'view' => $view_mode), admin_url('admin.php?page=videograph-ai-library&view=' . $view_mode));
            echo '<a href="' . esc_url($prev_url) . '" class="prev-page button">‹</a>';
        }
        for ($i = 1; $i <= $total_pages; $i++) {
            $page_url = add_query_arg(array('paged' => $i, 'view' => $view_mode), admin_url('admin.php?page=videograph-ai-library&view=' . $view_mode));
            $active_class = ($i === $current_page) ? 'active' : '';
            echo '<a href="' . esc_url($page_url) . '" class="' . $active_class . ' button">' . $i . '</a>';
        }
        if ($current_page < $total_pages) {
            $next_page = $current_page + 1;
            $next_url = add_query_arg(array('paged' => $next_page, 'view' => $view_mode), admin_url('admin.php?page=videograph-ai-library&view=' . $view_mode));
            echo '<a href="' . esc_url($next_url) . '" class="next-page button">›</a>';
        }
        echo '</div>';
    }
?>

    </div>


<style>
    /*table{
        border: none!important;
    }
    h1.wp-heading-inline{
        font-weight: 600;
    }
    .status p{
        display: none;
        align-items: center;
    }
    .status p span {
        font-size: 13px;
        width: 20px;
        height: 14px;
        line-height: 19px;
    }
    #Processing.status p.process, #Ready.status p.ready, #Failed.status p.failed {
        display: flex!important;
    }
    #Ready .ready span{
       color: #00e546!important;
    }
    #Failed .failed span{
        color: #ff0000!important;
    }
    .video-actions-menu li a span {
        font-size: 16px;
        line-height: 10px;
        height: 15px;
        width: auto;
        margin: 5px 5px 0 0;
    }
     .view-switch.list .view-list:before {
        color: #2271b1;
    }
    .view-switch.grid .view-grid:before {
        color: #2271b1;
    }
    .wp-filter .view-switch a{
            height: auto!important;
            padding: auto!important;
        }
        .wp-filter .view-switch{
            padding: 16px 0;
        }
    .video-popup-cnt h2{
        color: #23282d;
        font-size: 23px;
        font-weight: 600;
    }
        .library-wrap {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #fff;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .view-mode-buttons a{
            display: inline-block;
        }
        .view-mode-buttons .dashicons{
            text-decoration: none;
            color: #777;
        }
        .view-mode-buttons a.active .dashicons{
            color: #2271b1;
        }
        .view-mode-buttons a {
            margin-right: 10px;
        }
        .view-mode-buttons a.active {
            font-weight: bold;
        }

        .video-container.grid-view{
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 10px;
        }
        .video-container.grid-view table{
            display: none;
        }
        .video-container.grid-view .video-item {
            text-align: center;
            background-color: #ffffff;
            border-radius: 5px;
            overflow: hidden;
            border: 2px solid #e1e1e1;
            position: relative;
        }
        .video-container.grid-view .video-item:after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(0deg, #000000a6, transparent);
        }
        .video-container.grid-view .video-item a {
            text-decoration: none;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 999;
        }
        .video-container.grid-view .video-item figure {
            width: 100%;
            height: 120px;
            padding: 0;
            margin: 0;
            background-position: center;
            background-color: #717171;
        }
        .video-container.grid-view .video-item h3 {
            position: absolute;
            z-index: 99;
            left: 10px;
            margin: 0 auto;
            width: 90%;
            color: #fff;
            bottom: 10px;
            font-size: 14px;
            font-weight: 600;
            text-align: left;
        }
        .video-container.list-view .video-item{
            display: none;
        }
        .video-container.list-view {
            display: block;
        }
        .video-container.list-view tr th, .video-container.list-view tr td{
            vertical-align: middle;
        }
        .video-container.list-view table tbody td figure {
            width: 82px;
            height: 46px;
            margin: 0;
            padding: 0;
            background-size: cover;
            background-position: center;
        }
        .video-popup {
                display: none;
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background-color: #0000006b;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
                z-index: 9999;
                width: 98%;
                height: calc(100vh - 60px);
                padding: 40px 2% 2%;
                overflow: hidden;
            }
        .video-popup-cnt {
                background-color: #fff;
                border-radius: 10px;
                width: 100%;
                height: 98%;
                display: inline-block;
                overflow: hidden;
            }
        .video-popup-header {
                display: flex;
                justify-content: space-between;
                border-bottom: 1px solid #dcdcde;
                padding:0 0 0 20px;
            }
        .video-popup-header button {
                border: none;
                padding: 0 15px;
                cursor: pointer;
                color: #9ea3a8;
                background: #fff;
                border-left: 1px solid #9ea3a8;
            }
            .video-popup-header button:hover{
                color: #000;
            }
        .dashicons, .dashicons-before:before{
                width: 30px;
                height: 30px;
                font-size: 28px
            }
        .video-popup-main .video-popup-main-left {
                width: 64%;
                float: left;
                padding: 2%;
            }
        .video-popup-main .video-popup-main-right {
                width: 28%;
                float: left;
                padding: 2%;
                height: 100%;
            }
        .video-popup-main-right {
                background-color: #f6f7f7;
                text-align: left;
            }
        .video-details-top {
                padding-bottom: 20px;
                margin-bottom: 20px;
                border-bottom: 1px solid #dcdcde;
            }
            .video-details-top p, .video-details-main p{
                margin: 0 0 10px;
            }
            .video-details-main p{
                display: flex;
                gap: 10px;
            }
            .video-details-main p strong{
                width: 25%;
                float: left;
            }
            .video-details-main p input[type='text'], .video-details-main p textarea{
                width: 75%;
                float: left;
                box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, 0.07);
                border: solid 1px #ddd;
                color: #5f5f5f;
            }

            .vi-policy {
                display: inline-block;
                margin-bottom: 10px;
                margin-left: 27%;
            }

            .vi-policy p {
                width: auto;
                float: left;
                margin-right: 20px;
                align-items: center;
            }
            .vi-policy p strong {
                width: auto;
            }
            .vi-policy input[type=checkbox]:checked::before{
                margin: -.1875rem -3px 0px -.25rem;
            }
            .video-details-bottom {
                display: flex;
                justify-content: center;
                border-top: 1px solid #dcdcde;
                margin-top: 20px;
                padding-top: 20px;
                text-align: center;
            }
            .video-details-bottom span {
                margin: 0 15px;
                color: #ddd;
            }
            .video-popup.show {
                display: block;
            }

            .video-player {
                width: 100%;
                padding-bottom: 56.25%;
                position: relative;
                border-radius: 10px;
                overflow: hidden;
            }

            .video-player iframe {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
            }

            .video-details label {
                display: block;
                margin-top: 10px;
            }

            .video-details input[type="text"],
            .video-details textarea {
                width: 100%;
                max-width: 400px;
            }

            .video-delete {
                color: #ff0000;
                text-decoration: underline;
                cursor: pointer;
            }
            div.close-button {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1;
            }
            .video-iframe{
                position: relative;
                padding-bottom: 56.25%;
                height: 0;
                width: 100%;
            }

            .video-iframe iframe{
                position: absolute;
                top: 0;
                left: 0;
            }
            table tr th:nth-child(3), table tr td:nth-child(3) {
                width: 260px!important;
            }
            .pagination {
                margin-top: 20px;
                text-align: right;
            }
            .pagination a {
                color: #767676;
                text-decoration: none;
                padding: 2px 5px;
                border: 1px solid #767676;
                margin-right: 10px;
                display: inline-block;
                border-radius: 2px;
            }
            .pagination a.next-page, .pagination a.prev-page {
                font-size: 23px;
                line-height: 22px;
            }

            .pagination a {
                margin-right: 10px!important;
            }
            .pagination .displaying-num {
                line-height: 28px;
                margin-right: 13px;
            }
            thead tr th {
                font-weight: 600!important;
                color: #2271b1!important;
            }
            .video-actions {
                position: relative;
                display: inline-block;
            }

            .video-actions-btn {
                background: #eff1f1;
                border: none;
                cursor: pointer;
                outline: none;
                padding: 6px 15px 14px;
                border-radius: 100%;
            }

            .dots {
                display: inline-block;
                font-size: 34px;
                line-height: 0px;
                color: #818181;
                position: relative;
            }

            .dots:before {
                content: ".";
                position: absolute;
                top: -8px;
                left: 0;
                right: 0;
                margin: 0 auto;
            }

            .dots:after {
                content: ".";
                position: absolute;
                top: 8px;
                left: 0;
                right: 0;
                margin: 0 auto;
            }

            .video-actions-menu {
                position: absolute;
                top: 25px;
                right: 20px;
                background-color: #fff;
                min-width: 160px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.15);
                border-radius: 4px;
                padding: 0;
                display: none;
                z-index: 999;
            }

            .video-actions-menu.show {
                display: block;
            }

            .video-actions-menu ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
            }

            .video-actions-menu ul li {
                margin: 0;
                cursor: pointer;
                border-bottom: 1px solid #818181;
            }

            .video-actions-menu ul li:last-child {
                border: none;
            }
            .video-actions-menu ul li a {
                color: #818181;
                font-weight: 500;
                padding: 12px 16px;
                display: block;
            }
            .video-actions-menu ul li:hover {
                background-color: #f1f1f1;
            }
            #videos-per-page-form {
                float: right;
                margin: 10px 0 10px 20px;
            }
            .video-actions:hover .video-actions-menu {
                display: block;
            }*/
</style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {

            var videoDeleteLinks = document.querySelectorAll('.video-delete');

            videoDeleteLinks.forEach(function (link) {
                link.addEventListener('click', function (event) {
                    event.preventDefault();
                    var streamId = this.getAttribute('data-content-id');
                    deleteVideo(streamId);
                });
            });

            var videoThumbnails = document.querySelectorAll('.video-thumbnail');
            videoThumbnails.forEach(function(thumbnail) {
                thumbnail.addEventListener('click', function(e) {
                    e.preventDefault();
                    var videoPopupId = this.getAttribute('href');
                    var videoPopup = document.querySelector(videoPopupId);
                    if (videoPopup) {
                        videoPopup.classList.add('show');
                        var iframe = videoPopup.querySelector('iframe');
                        if (iframe) {
                            // Start playing the video when the popup is opened
                            iframe.src = iframe.src.replace('autoplay=0', 'autoplay=1');
                        }
                    }
                });
            });

            var closeButtons = document.querySelectorAll('.close-button');
            closeButtons.forEach(function(button) {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    var videoPopup = this.closest('.video-popup');
                    if (videoPopup) {
                        var iframe = videoPopup.querySelector('iframe');
                        if (iframe) {
                            // Stop the video when the popup is closed
                            iframe.src = iframe.src.replace('autoplay=1', 'autoplay=0');
                        }
                        videoPopup.classList.remove('show');
                    }
                });
            });

            var closeButtons = document.querySelectorAll('.close-button');
            closeButtons.forEach(function(button) {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    var videoPopup = this.closest('.video-popup');
                    if (videoPopup) {
                        videoPopup.classList.remove('show');
                    }
                });
            });

            var copyButtons = document.querySelectorAll('.copy-button');
            copyButtons.forEach(function(copyButton) {
                copyButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    var inputField = this.previousElementSibling;
                    inputField.select();
                    document.execCommand('copy');
                    alert('Shortcode copied to clipboard!');
                });
            });

            function deleteVideo(contentId) {
                var xhr = new XMLHttpRequest();
                xhr.open('DELETE', 'https://api.videograph.ai/video/services/api/v1/contents/' + contentId);
                xhr.setRequestHeader('Authorization', 'Basic <?php echo base64_encode($access_token . ':' . $secret_key); ?>');
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        alert('Video deleted successfully!');
                        location.reload(); // Reload the library page
                    } else {
                        alert('Failed to delete the video. Error code: ' + xhr.status);
                    }
                };
                xhr.send();
            }
        });

        // Function to search and reload videos
        jQuery(document).ready(function ($) {
            // Function to filter table rows based on search input
            function filterTableRows(searchQuery) {
                const $tableRows = $('#the-list tr');

                $tableRows.each(function () {
                    const contentId = $(this).find('td:nth-child(3)').text();
                    const title = $(this).find('td:nth-child(2)').text();

                    if (
                        contentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        title.toLowerCase().includes(searchQuery.toLowerCase())
                    ) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            }

            // Event listener for search input changes
            $('#media-search-input').on('input', function () {
                const searchQuery = $(this).val();
                filterTableRows(searchQuery);
            });
        });


        // Function to submit the form when the "Videos per page" dropdown value changes
        document.getElementById('videos-per-page').addEventListener('change', function() {
            document.getElementById('videos-per-page-form').submit();
        });

        // Initialize the "Videos per page" dropdown with the current value
        const currentVideosPerPage = <?php echo $per_page; ?>;
        document.getElementById('videos-per-page').value = currentVideosPerPage;

        </script>
    <?php
}