<?php

function videograph_ai_livestream_recording_shortcode($atts) {
    $atts = shortcode_atts( array(
        'stream_id' => '',
    ), $atts, 'videograph-livestream' );

    if (empty($atts['stream_id'])) {
        return '<p>Error: Livestream ID is missing.</p>';
    }

    $streamId = sanitize_text_field($atts['stream_id']);

    return '<div class="video-iframe"><iframe width="100%" height="100%" src="https://dashboard.videograph.ai/videos/embed?streamId=' . $streamId . '" frameborder="0" allowfullscreen></iframe> </div>';
}
add_shortcode('videograph-livestream', 'videograph_ai_livestream_shortcode');



// Livestream Recording Videos page
function videograph_ai_live_recording_videos_page()
{
    // Check if API keys are inserted
    $access_token = get_option('videograph_ai_access_token');
    $secret_key = get_option('videograph_ai_secret_key');

    if (empty($access_token) || empty($secret_key)) {
        echo '<div class="vi-notice-error"><p>Please insert your API keys in the <a href="' . admin_url('admin.php?page=videograph-ai-settings') . '">Settings</a> page to fetch Livestream videos.</p></div>';
        return;
    }

    // Fetch Livestream videos
    $api_url = 'https://api.videograph.ai/video/services/api/v1/livestreams?record=true';
    $headers = array(
        'Authorization: Basic ' . base64_encode($access_token . ':' . $secret_key),
        'Content-Type: application/json',
    );

    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => $api_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => $headers,
    ]);

    $response = curl_exec($curl);
    $error = curl_error($curl);
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

    curl_close($curl);

    if ($error) {
        echo '<div class="notice notice-error"><p>cURL Error: ' . $error . '</p></div>';
    } else {
        // Check if the API request was successful
        if ($http_code === 200) {
            $response_data = json_decode($response, true);

            if ($response_data['status'] === 'Success') {
                $livestreams = $response_data['data'];

            $search_query = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

            // Custom filtering function based on the search query
            function custom_video_filter($content, $search_query) {
                return strpos($livestream['streamUUID'], $search_query) !== false
                    || strpos($livestream['title'], $search_query) !== false;
            }

            // Filter videos based on the search query
            if (!empty($search_query)) {
                $filtered_videos = array_filter($livestreams, function ($content) use ($search_query) {
                    return custom_video_filter($content, $search_query);
                });
            } else {
                $filtered_videos = $livestreams;
            }

            // If search query provided and no matching videos found
            if (!empty($search_query) && empty($filtered_videos)) {
                echo '<div class="notice notice-warning"><p>No Videos found matching the search query: ' . esc_html($search_query) . '</p></div>';
            }

            $per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 5; // Number of videos per page
            $total_videos = count($livestreams);
            $total_pages = ceil($total_videos / $per_page);
            $current_page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;

            $start_index = ($current_page - 1) * $per_page;
            $end_index = $start_index + $per_page;
            $livestreams_data = array_slice($filtered_videos, $start_index, $per_page);

            ?>


        <div class="wrap">
            <h1 class="wp-heading-inline">Live Stream Videos</h1>
            <a href="<?php echo admin_url('admin.php?page=videograph-ai-live-stream') ?>" class="page-title-action">Create Live Stream</a>
            <hr class="wp-header-end"><br>

            <div class="wp-filter">
                <div class="search-form">
                    <label for="media-search-input" class="media-search-input-label">Search</label>
                    <input type="search" id="media-search-input" class="search" name="s" value="<?php echo esc_attr($search_query); ?>" />
                </div>

                <form id="videos-per-page-form" method="GET" action="<?php echo esc_url(admin_url('admin.php?page=videograph-ai-live-recording-videos-page')); ?>">
                   <input type="hidden" name="page" value="videograph-ai-live-recording-videos-page">
                    <div class="videos-count">
                        <label for="videos-per-page">Videos per page</label>
                        <select id="videos-per-page" name="per_page">
                            <option value="10" <?php selected($per_page, 10); ?> selected>10</option>
                            <option value="20" <?php selected($per_page, 20); ?>>20</option>
                            <option value="30" <?php selected($per_page, 30); ?>>30</option>
                            <!-- Add other options as needed -->
                        </select>
                        <input type="submit" name="submit" value="Submit"  class="button button-primary">
                    </div>
                </form>
            </div>
                        <?php
                        // Process the livestreams data
                        if (!empty($livestreams)) { ?>
                <div class="livestream-table">        
                <table class="wp-list-table widefat fixed striped table-view-list posts">
                    <thead>
                        <tr>
                            <th scope="col">Created at</th>
                            <th scope="col">Title</th>
                            <th scope="col">Video ID</th>
                            <th scope="col">Thumbnail</th>
                            <th scope="col">Status</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="the-list">
                        <?php
                            foreach ($livestreams_data as $livestream) {
                                // Extract and display the livestream details
                                $streamId = $livestream['streamUUID'];
                                $title = $livestream['title'];
                                $thumbnailUrl = $livestream['thumbnailUrl'] ?? '';
                                //$createdOn = date("d/m/y h:i a", $livestream['created_at']);
                                $status = $livestream['status'];
                                $created_at = $livestream['created_at'];
                                $timestamp = $created_at / 1000;
                                $createdOn = date('Y-m-d H:i:s', strtotime('@' . $timestamp));
                                ?>

                                <tr>
                                    <td> <?php echo "$createdOn"; ?> </td>
                                    <td> <?php echo "$title"; ?> </td>
                                    <td>
                                        <a href="#" class="view-details-link" data-stream-id="<?php echo $streamId; ?>">
                                            <?php echo "$streamId"; ?>
                                        </a>
                                    </td>
                                    <td>
                                        <a href="#" class="view-details-link" data-stream-id="<?php echo $streamId; ?>">                                            
                                            <figure style="background-image: url(<?php echo "$thumbnailUrl"; ?>);"></figure>
                                        </a>
                                    </td>
                                    <td id="<?php echo esc_attr($livestream['status']); ?>" class="status">
                                        <p class="idle">Idle <span class="dashicons dashicons-clock"></span></p>
                                        <p class="active">Active <span class="dashicons dashicons-yes-alt"></span></p>
                                    </td>
                                    <td>
                                        <div class="video-actions">
                                            <button class="video-actions-btn">
                                                <span class="dots">.</span>
                                            </button>
                                            <div class="video-actions-menu">
                                                <ul>
                                                    <li><a href="#" class="view-details-link" data-stream-id="<?php echo $streamId; ?>">
                                                        <span class="dashicons dashicons-info"></span>Livestream Details
                                                    </a></li>
                                                    <li><a href="#" class="video-delete" data-stream-id="<?php echo $streamId; ?>">
                                                        <span class="dashicons dashicons-trash"></span>Delete Livestream
                                                    </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?></tbody>
                        </table>
                    </div>
                </div>
                        <?php
                        }else {
                            ?>
                            <div class="notice notice-error">
                                <p>No livestream videos found. You can Create Live Stream Videos <a href="<?php echo admin_url('admin.php?page=videograph-ai-live-stream') ?>">here</a></p>
                            </div>
                        <?php
                        }
                    ?>

                <div class="popup-content">
                    <div class="popup-overlay"></div>
                    <button class="close-popup"><span class="dashicons dashicons-no"></span></button>
                    <div id="liveStreamDetailsPopup">
                        
                    </div>
                </div>

                <script>

                    function fetchLiveStreamDetails(streamId) {
                        // Make API call to fetch livestream details
                        var apiUrl = 'https://api.videograph.ai/video/services/api/v1/livestreams/' + streamId;
                        var headers = {
                            'Authorization': 'Basic <?php echo base64_encode($access_token . ':' . $secret_key); ?>',
                            'Content-Type': 'application/json'
                        };

                        fetch(apiUrl, {
                            method: 'GET',
                            headers: headers
                        })
                            .then(response => response.json())
                            .then(data => {
                                // Process and display the livestream details in the popup
                                var livestreamDetails = data.data;
                                var title = livestreamDetails.title;
                                var description = livestreamDetails.description;
                                var ingestUrl = livestreamDetails.ingestUrl;
                                var streamKey = livestreamDetails.streamKey;
                                var streamUUID = livestreamDetails.streamUUID;
                                var playbackUrl = livestreamDetails.playbackUrl;
                                var createdOn = livestreamDetails.createdOn;
                                var status = livestreamDetails.status;

                                var popupContent = `

                                            <div class="livestream-popup-cnt">
                                            <div class="livestream-popup-header">
                                                <h2>Live Stream Recording Video Details</h2>
                                            </div>
                                            <div class="livestream-popup-main">
                                                <div class="livestream-popup-main-left">
                                                    <div class="livestream-player">
                                                        <span class="${status}">${status}</span>
                                                        <iframe width="100%" style="position: absolute; height: 100%; border: none" src="https://dashboard.videograph.ai/videos/embed?streamId=${streamUUID}" allowfullscreen></iframe>
                                                    </div>
                                                </div>
                                                <div class="livestream-popup-main-right">
                                                    <div class="livestream-details-top">
                                                        <p><strong>Live Stream ID: </strong> ${streamUUID}</p>
                                                        <p><strong>File Name: </strong> ${title}</p>
                                                        <p><strong>Created On: </strong> ${createdOn}</p>
                                                        <p><strong>Published On: </strong> ${createdOn}</p>
                                                    </div>
                                                    <div class="livestream-details-main">
                                                        <p>
                                                            <strong>Title: </strong> 
                                                            <input type="text" value="${title}">
                                                        </p>
                                                        <p>
                                                            <strong>Description: </strong>
                                                            <textarea>${description}</textarea>
                                                        </p>
                                                        <p>
                                                            <strong>RTMP URL: </strong>
                                                            <input type="text" value="${ingestUrl}" readonly>
                                                        </p>
                                                        <p>
                                                            <strong>Stream Key: </strong>
                                                            <input type="text" value="${streamKey}" readonly>
                                                        </p>
                                                        <p>
                                                            <strong>Short Code: </strong>
                                                            <input type="text" value="[videograph-livestream stream_id='${streamUUID}']" readonly>
                                                        </p>
                                                    </div>
                                                    <div class="livestream-details-bottom">
                                                        <a href="https://dashboard.videograph.ai/" target="_blank">Edit on videograph.ai</a>
                                                        <span>|</span>
                                                        <a href="#" class="video-delete" data-stream-id="${streamUUID}">Delete Permanently</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                `;

                                document.getElementById('liveStreamDetailsPopup').innerHTML = popupContent;
                                document.querySelector('.popup-overlay').style.display = 'block';
                                document.querySelector('.popup-content').style.display = 'block';

                                var deleteVideoLink = document.querySelector('.popup-content .video-delete');
                                if (deleteVideoLink) {
                                    deleteVideoLink.addEventListener('click', function (event) {
                                        event.preventDefault();
                                        var streamId = this.getAttribute('data-stream-id');
                                        deleteVideo(streamId);
                                    });
                                }

                                function deleteVideo(streamId) {
                                if (confirm("Are you sure you want to delete this video?")) {
                                    var apiUrl = 'https://api.videograph.ai/video/services/api/v1/livestreams/' + streamId;
                                    var headers = {
                                        'Authorization': 'Basic <?php echo base64_encode($access_token . ':' . $secret_key); ?>',
                                        'Content-Type': 'application/json'
                                    };

                                    fetch(apiUrl, {
                                        method: 'DELETE',
                                        headers: headers
                                    })
                                        .then(response => response.json())
                                        .then(data => {
                                            if (data.status === 'Success') {
                                                // Video deleted successfully
                                                // You can update the UI or perform any other action as needed
                                                location.reload(); // Refresh the page to update the video list
                                            } else {
                                                // Failed to delete the video
                                                alert('Failed to delete the video. Please try again.');
                                            }
                                        })
                                        .catch(error => {
                                            console.log('Error:', error);
                                        });
                                }
                            }
                            
                            })
                            .catch(error => {
                                console.log('Error:', error);
                            });
                    }

                        document.addEventListener('DOMContentLoaded', function () {
                        /*var videoActionsBtns = document.querySelectorAll('.video-actions-btn');
                        videoActionsBtns.forEach(function (btn) {
                            btn.addEventListener('click', function () {
                                var menu = this.nextElementSibling;
                                menu.classList.toggle('show');
                            });
                        });*/


                        var viewDetailsLinks = document.querySelectorAll('.view-details-link');

                        viewDetailsLinks.forEach(function (link) {
                            link.addEventListener('click', function (event) {
                                event.preventDefault();
                                var streamId = this.getAttribute('data-stream-id');
                                fetchLiveStreamDetails(streamId);
                            });
                        });

                        var closePopupBtn = document.querySelector('.close-popup');
                        var popupOverlay = document.querySelector('.popup-overlay');
                        var popupContent = document.querySelector('.popup-content');

                        closePopupBtn.addEventListener('click', function () {
                            popupOverlay.style.display = 'none';
                            popupContent.style.display = 'none';
                        });

                        popupOverlay.addEventListener('click', function () {
                            popupOverlay.style.display = 'none';
                            popupContent.style.display = 'none';
                        });

                                // Delete video functionality
                        var deleteVideoLinks = document.querySelectorAll('.video-delete');
                            deleteVideoLinks.forEach(function (link) {
                                link.addEventListener('click', function (event) {
                                    event.preventDefault();
                                    var streamId = this.getAttribute('data-stream-id');
                                    deleteVideo(streamId);
                                });
                            });

                        function deleteVideo(streamId) {
                            if (confirm("Are you sure you want to delete this video?")) {
                                var apiUrl = 'https://api.videograph.ai/video/services/api/v1/livestreams/' + streamId;
                                var headers = {
                                    'Authorization': 'Basic <?php echo base64_encode($access_token . ':' . $secret_key); ?>',
                                    'Content-Type': 'application/json'
                                };

                                fetch(apiUrl, {
                                    method: 'DELETE',
                                    headers: headers
                                })
                                    .then(response => response.json())
                                    .then(data => {
                                        if (data.status === 'Success') {
                                            // Video deleted successfully
                                            // You can update the UI or perform any other action as needed
                                            location.reload(); // Refresh the page to update the video list
                                        } else {
                                            // Failed to delete the video
                                            alert('Failed to delete the video. Please try again.');
                                        }
                                    })
                                    .catch(error => {
                                        console.log('Error:', error);
                                    });
                            }
                        }
                    });
                </script>


    <div class="wrap">
    
        <?php

        // Pagination HTML
        if ($total_pages > 1) {
            echo '<div class="pagination">';
            echo '<span class="displaying-num">' . $total_videos  . ' items </span>';

            if ($current_page > 1) {
                $prev_page = $current_page - 1;
                $prev_url = add_query_arg(array('paged' => $prev_page), admin_url('admin.php?page=videograph-ai-live-recording-videos-page'));
                echo '<a href="' . esc_url($prev_url) . '" class="prev-page button">‹</a>';
            }
            for ($i = 1; $i <= $total_pages; $i++) {
                $page_url = add_query_arg(array('paged' => $i), admin_url('admin.php?page=videograph-ai-live-recording-videos-page'));
                $active_class = ($i === $current_page) ? 'active' : '';
                echo '<a href="' . esc_url($page_url) . '" class="' . $active_class . ' button">' . $i . '</a>';
            }
            if ($current_page < $total_pages) {
                $next_page = $current_page + 1;
                $next_url = add_query_arg(array('paged' => $next_page), admin_url('admin.php?page=videograph-ai-live-recording-videos-page'));
                echo '<a href="' . esc_url($next_url) . '" class="next-page button">›</a>';
            }
            echo '</div>';
        }
        ?>
    </div>





<!-- <style>
    h1.wp-heading-inline{
        font-weight: 600;
    }
    .wp-filter{
        display: flex!important;
        justify-content: space-between!important;
    }
    table{
        border: none!important;
    }
    .status p{
        display: none;
        align-items: center;
    }
    .status p span {
        font-size: 13px;
        width: 20px;
        height: 14px;
        line-height: 19px;
    }
    #Idle .idle, #Active .active{
        display: flex;
    }

    #Active .active span{
       color: #00e546;
    }
    /*#idle .idle span{
        color: #ff0000;
    }*/
    .video-actions-menu li a span {
        font-size: 16px;
        line-height: 10px;
        height: 15px;
        width: auto;
        margin: 5px 5px 0 0;
        color: #7c90a8;
    }


    .livestream-table {
            display: block;
        }
        .livestream-table table tbody td figure {
            width: 82px;
            height: 46px;
            margin: 0;
            padding: 0;
            background-size: cover;
            background-position: center;
            background-color: #7a7a7a;
        }

        .livestream-table tr td{
        vertical-align: middle;
    }
    .popup-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: none;
        z-index: -1;
    }
    .popup-content h2 {
        margin: 0;
        padding: 20px 0;
        color: #23282d;
        font-size: 23px;
        font-weight: 600;
    }
    .close-popup {
        position: absolute;
        top: 40px;
        right: 2%;
        color: #888;
        cursor: pointer;
        z-index: 999;
        padding: 14px;
        background: transparent;
        border: none;
        border-left: 1px solid #dcdcdc;
    }
    .popup-content {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #0000006b;
        z-index: 9999;
        width: 96%;
        height: calc(100vh - 60px);
        padding: 40px 2% 2%;
        overflow: hidden;
}

    .livestream-popup-cnt {
        background-color: #fff;
        border-radius: 10px;
        width: 100%;
        height: 98%;
        display: inline-block;
        overflow: hidden;

}
    .livestream-popup-header {
        display: flex;
        justify-content: space-between;
        border-bottom: 1px solid #dcdcde;
        padding:0 0 0 20px;
}
    .livestream-popup-header button {
        border: none;
        padding: 0 15px;
    }
    .dashicons, .dashicons-before:before{
        width: 30px;
        height: 30px;
        font-size: 28px
    }
    .livestream-popup-main .livestream-popup-main-left {
        width: 64%;
        float: left;
        padding: 2%;
    }
    .livestream-popup-main .livestream-popup-main-right {
        width: 28%;
        float: left;
        padding: 2%;
        background-color: #f6f7f7;
        text-align: left;
        height: 100%;
    }
    .livestream-details-top {
        padding-bottom: 30px;
        margin-bottom: 30px;
        border-bottom: 1px solid #dcdcde;
    }
    .livestream-details-top p, .livestream-details-main p{
        margin: 0 0 10px;
    }
    .livestream-details-main p{
        display: flex;
        gap: 10px;
    }
    .livestream-details-main p strong{
        width: 25%;
        float: left;
    }
    .livestream-details-main p input[type='text'], .livestream-details-main p textarea{
        width: 75%;
        float: left;
        box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, 0.07);
        border: solid 1px #ddd;
        color: #5f5f5f;
    }
    .vi-policy {
                display: inline-block;
                margin-bottom: 10px;
                margin-left: 27%;
            }

            .vi-policy p {
                width: auto;
                float: left;
                margin-right: 30px;
                align-items: center;
            }
            .vi-policy p strong {
                width: auto;
            }
            .vi-policy input[type=checkbox]:checked::before{
                margin: -.1875rem -3px 0px -.25rem;
            }
    .livestream-details-bottom {
        display: flex;
        justify-content: left;
        border-top: 1px solid #dcdcde;
        margin-top: 20px;
        padding-top: 20px;
        text-align: center;
    }
    .livestream-details-bottom span{
        margin: 0 20px;
        color: #dcdcdc;
    }
    .livestream-details-bottom .video-delete{
        text-decoration: none;
        color: #aa0000;
    }
    .livestream-popup.show {
        display: block;
    }

    .livestream-player {
        width: 100%;
        padding-bottom: 56.25%;
        position: relative;
        border-radius: 10px;
        overflow: hidden;
    }
    .livestream-player span {
        position: absolute;
        top: 10px;
        left: 10px;
        z-index: 999;
        padding: 5px 10px 5px 30px;
        border: 1px solid #707070;
        border-radius: 5px;
        font-size: 14px;
        color: #707070;
        font-weight: 600;
    }
    .livestream-player span:after {
        content: '';
        position: absolute;
        top: 8px;
        left: 7px;
        width: 12px;
        height: 12px;
        background-color: #707070;
        border-radius: 100%;
        color: #707070;
    }
    .livestream-player span.active:after {
        background-color: #00e546;
    }

    .livestream-player iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }

    .livestream-details label {
        display: block;
        margin-top: 10px;
    }

    .livestream-details input[type="text"],
    .livestream-details textarea {
        width: 100%;
        max-width: 400px;
        box-shadow: inset 0 1px 2px 0 rgba(0, 0, 0, 0.07);
        border: solid 1px #ddd;
        color: #5f5f5f;
    }
    .livestream-actions {
        margin-top: 10px;
    }

    .livestream-delete {
        color: #ff0000;
        text-decoration: underline;
        cursor: pointer;
    }
    table tr th:nth-child(3), table tr td:nth-child(3) {
                width: 260px!important;
            }
            .pagination {
                margin-top: 20px;
                text-align: right;
            }
            .pagination a {
                color: #767676;
                text-decoration: none;
                padding: 2px 5px;
                border: 1px solid #767676;
                margin-right: 10px;
                display: inline-block;
                border-radius: 2px;
            }
            .pagination a.next-page, .pagination a.prev-page {
                font-size: 23px;
                line-height: 22px;
            }

            .pagination a {
                margin-right: 10px!important;
            }
            .pagination .displaying-num {
                line-height: 28px;
                margin-right: 13px;
            }
            thead tr th {
                font-weight: 600!important;
                color: #2271b1!important;
            }
            .livestream-table tr td:last-child, .livestream-table tr th:last-child {
                width: 70px;
                text-align: center;
            }
            
.video-actions {
    position: relative;
    display: inline-block;
}

.video-actions:hover .video-actions-menu {
    display: block;
}

.video-actions-btn {
    background: #eff1f1;
    border: none;
    cursor: pointer;
    outline: none;
    padding: 6px 15px 14px;
    border-radius: 100%;
}

.dots {
    display: inline-block;
    font-size: 34px;
    line-height: 0px;
    color: #818181;
    position: relative;
}

.dots:before {
    content: ".";
    position: absolute;
    top: -8px;
    left: 0;
    right: 0;
    margin: 0 auto;
}

.dots:after {
    content: ".";
    position: absolute;
    top: 8px;
    left: 0;
    right: 0;
    margin: 0 auto;
}

.video-actions-menu {
    position: absolute;
    top: 25px;
    right: 20px;
    background-color: #fff;
    min-width: 180px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.15);
    border-radius: 4px;
    padding: 0;
    display: none;
    z-index: 999;
}

.video-actions-menu.show {
    display: block;
}

.video-actions-menu ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}

.video-actions-menu ul li {
    margin: 0;
    cursor: pointer;
    border-bottom: 1px solid #818181;
}

.video-actions-menu ul li:last-child {
    border: none;
}
.video-actions-menu ul li a {
    color: #818181;
    font-weight: 500;
    padding: 12px 16px;
    display: block;
}
.video-actions-menu ul li:hover {
    background-color: #f1f1f1;
}
#videos-per-page-form {
    float: right;
    margin: 10px 0 10px 20px;
}
</style> -->

                <script>
                    // Function to search and reload videos
                    jQuery(document).ready(function ($) {
                        // Function to filter table rows based on search input
                        function filterTableRows(searchQuery) {
                            const $tableRows = $('#the-list tr');

                            $tableRows.each(function () {
                                const contentId = $(this).find('td:nth-child(3)').text();
                                const title = $(this).find('td:nth-child(2)').text();

                                if (
                                    contentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                    title.toLowerCase().includes(searchQuery.toLowerCase())
                                ) {
                                    $(this).show();
                                } else {
                                    $(this).hide();
                                }
                            });
                        }

                        // Event listener for search input changes
                        $('#media-search-input').on('input', function () {
                            const searchQuery = $(this).val();
                            filterTableRows(searchQuery);
                        });
                    });

                    // Function to submit the form when the "Videos per page" dropdown value changes
                    document.getElementById('videos-per-page').addEventListener('change', function() {
                        document.getElementById('videos-per-page-form').submit();
                    });

                    // Initialize the "Videos per page" dropdown with the current value
                    const currentVideosPerPage = <?php echo $per_page; ?>;
                    document.getElementById('videos-per-page').value = currentVideosPerPage;
                </script>

                <?php
            } else {
                echo '<div class="notice notice-error"><p>' . $response_data['message'] . '</p></div>';
            }
        } else {
            echo '<div class="notice notice-error"><p>Failed to fetch live stream videos from Videograph AI API. Check your API Credentials in <a href="' . admin_url('admin.php?page=videograph-ai-settings') . '">Settings</a> Page</p></div';
        }
    }
}