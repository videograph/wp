<?php
// Silence is Golden

// old
//49e21c90-dbd2-44f5-aa9e-3f17516dbd6d
//s5i6euinkoil3aqcdv


// test dashboard
//664392be-7ee7-4c49-883a-0d28886e509f
//as72bdmgu5los98l3u


// may mail
// 67324b3f-eec2-42d8-b877-58c6db67b71f
// j1htr3ov0k2nak5926


//Subscription
//ffc43960-2422-47f5-9042-9261707e326a
//o4art872mubca0q1ac